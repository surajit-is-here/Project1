public class MyMain {
    public static void main(String[] args) {
        new ClassMain();
    }
}
